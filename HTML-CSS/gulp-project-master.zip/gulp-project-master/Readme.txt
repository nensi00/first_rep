###need install gulp on global-cli### відкрити термінал і глобально заінсталити gulp-cli
npm install --global gulp-cli 

###якшо буде помилка з node-sass то ставимо ще глобально node-sass npm install --global node-sass

###install project###
cd on folder ==> package.json зайти в папку де знаходится файлік package.json
npm install

###start project### щоб стартонути проєкт треба в термінали написати
npm run start        Запустити в режимі розробника
npm run start:build      Запустити в режимі продакшену

